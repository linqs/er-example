#!/usr/bin/python

import re
import random

fin = open("citeseer.dat", 'r')

authorName = dict()
authorNormName = dict()
authorCluster = dict()
paperAuthor = dict()
paperCluster = dict()
paperTitle = dict()
papersby = dict()

for line in fin:
	tokens = re.split("\s+\\|\s+", line.strip())

	if len(tokens) == 8:

		author_id = tokens[0]
		author_cluster_id = tokens[1]
		normalized_author = tokens[2]
		full_author = tokens[3]
		paper_id = tokens[5]
		paper_cluster_id = tokens[6]
		title = tokens[7]

		
		# load data into structures
		authorName[author_id] = full_author
		authorNormName[author_id] = normalized_author
		if author_cluster_id not in authorCluster:
			authorCluster[author_cluster_id] = set()
		authorCluster[author_cluster_id].add(author_id)

		if author_cluster_id not in papersby:
			papersby[author_cluster_id] = set()
		papersby[author_cluster_id].add(paper_id)

		if paper_id not in paperAuthor:
			paperAuthor[paper_id] = set()
		paperAuthor[paper_id].add(author_id)

		if paper_cluster_id not in paperCluster:
			paperCluster[paper_cluster_id] = set()
		paperCluster[paper_cluster_id].add(paper_id)

		paperTitle[paper_id] = title # this will overwrite many times, but it should be fast

	else:
		if len(tokens)>1:
			print "Error parsing line: " + line


nameEntities = dict()

for cluster in authorCluster:
	for author in authorCluster[cluster]:
		tokens = re.split("_", authorNormName[author])
		lastname = tokens[0]
		if lastname not in nameEntities:
			nameEntities[lastname] = set()
		nameEntities[lastname].add(cluster)

for lastname in nameEntities:
	print "%s\t%d" % (lastname, len(nameEntities[lastname]))
