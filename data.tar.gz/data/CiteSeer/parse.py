#!/usr/bin/python

import re
import random

fin = open("citeseer.dat", 'r')

authorName = dict()
authorNormName = dict()
authorCluster = dict()
paperAuthor = dict()
paperCluster = dict()
paperTitle = dict()
papersby = dict()

for line in fin:
	tokens = re.split("\s+\\|\s+", line)

	if len(tokens) == 8:

		author_id = tokens[0]
		author_cluster_id = tokens[1]
		normalized_author = tokens[2]
		full_author = tokens[3]
		paper_id = tokens[5]
		paper_cluster_id = tokens[6]
		title = tokens[7]

		
		# load data into structures
		authorName[author_id] = full_author
		authorNormName[author_id] = normalized_author
		if author_cluster_id not in authorCluster:
			authorCluster[author_cluster_id] = set()
		authorCluster[author_cluster_id].add(author_id)

		if author_cluster_id not in papersby:
			papersby[author_cluster_id] = set()
		papersby[author_cluster_id].add(paper_id)

		if paper_id not in paperAuthor:
			paperAuthor[paper_id] = set()
		paperAuthor[paper_id].add(author_id)

		if paper_cluster_id not in paperCluster:
			paperCluster[paper_cluster_id] = set()
		paperCluster[paper_cluster_id].add(paper_id)

		paperTitle[paper_id] = title # this will overwrite many times, but it should be fast

	else:
		if len(tokens)>1:
			print "Error parsing line: " + line

numFolds = dict()
numFolds['tiny'] = 10
numFolds['small'] = 5
numFolds['medium'] = 3
numFolds['big'] = 2


for folder in ['tiny', 'small', 'medium', 'big']:

	FOLDS = numFolds[folder]


	# split data

	authorSplit = [set() for index in range(FOLDS)]
	paperSplit = [set() for index in range(FOLDS)]

	for cluster in authorCluster:
		fold = random.randint(0,FOLDS-1)

		for author in authorCluster[cluster]:
			authorSplit[fold].add(author)

		for paper in papersby[cluster]:
			paperSplit[fold].add(paper)


	#######################
	# write out files
	#######################

	FOLDSOUT = 2

	for fold in range(0,FOLDSOUT):
		# write authorName
		fout = open('%s/authorName.%d.txt' % (folder, fold), 'w')
		for author in authorName:
			if author in authorSplit[fold]:
				fout.write("%s\t%s\n" % (author, authorName[author]))
		fout.close()

		# write AuthorNormName
		fout = open('%s/authorNormName.%d.txt' % (folder, fold), 'w')
		for author in authorNormName:
			if author in authorSplit[fold]:
				fout.write("%s\t%s\n" % (author, authorName[author]))
		fout.close()

		# write paperTitle
		fout = open('%s/paperTitle.%d.txt' % (folder, fold), 'w')
		for paper in paperTitle:
			if paper in paperSplit[fold]:
				fout.write("%s\t%s\n" % (paper, paperTitle[paper]))
		fout.close()

		# write authorOf
		fout = open('%s/authorOf.%d.txt' % (folder, fold), 'w')
		for paper in paperAuthor:
			for author in paperAuthor[paper]:
				if paper in paperSplit[fold] and author in authorSplit[fold]:
					fout.write("%s\t%s\n" % (author, paper))
		fout.close()

		# write coauthor
		fout = open('%s/coauthor.%d.txt' % (folder, fold), 'w')
		for paper in paperAuthor:
			for author1 in paperAuthor[paper]:
				for author2 in paperAuthor[paper]:
					if author1 is not author2 and author1 in authorSplit[fold] and author2 in authorSplit[fold]:
						fout.write("%s\t%s\n" % (author1, author2))
		fout.close()

		# write sameAuthor
		fout = open('%s/sameAuthor.%d.txt' % (folder, fold), 'w')
		for cluster in authorCluster:
			for author1 in authorCluster[cluster]:
				for author2 in authorCluster[cluster]:
					if author1 in authorSplit[fold] and author2 in authorSplit[fold]:
						fout.write("%s\t%s\t1.0\n" % (author1, author2))
		fout.close()

		# write samePaper
		fout = open('%s/samePaper.%d.txt' % (folder, fold), 'w')
		for cluster in paperCluster:
			for paper1 in paperCluster[cluster]:
				for paper2 in paperCluster[cluster]:
					if paper1 in paperSplit[fold] and paper2 in paperSplit[fold]:
						fout.write("%s\t%s\t1.0\n" % (paper1, paper2))
		fout.close()





